import React, { useState } from "react";
import { auth, db } from "../firebase";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { useNavigate } from "react-router-dom";

export default function Login({ role }) {
  const navigate = useNavigate();
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      if (isRegister) {
        // Crear usuario
        const res = await createUserWithEmailAndPassword(auth, email, password);

        // Guardar en Firestore: rol del usuario
        await setDoc(doc(db, "usuarios", res.user.uid), {
          email,
          role,
          createdAt: new Date().toISOString()
        });

        alert("Cuenta creada correctamente");
      } else {
        // Iniciar sesión
        await signInWithEmailAndPassword(auth, email, password);
      }

      // Redirecciones según el rol
      if (role === "conductor") {
        navigate("/panel-conductor");
      } else {
        navigate("/home");
      }

    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div style={{ maxWidth: 380, margin: "50px auto", padding: 20, border: "1px solid #ddd", borderRadius: 10 }}>
      <h2>{isRegister ? "Crear Cuenta" : "Iniciar Sesión"} ({role})</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Correo"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{ width: "100%", padding: 10, marginBottom: 10 }}
        />
        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={{ width: "100%", padding: 10, marginBottom: 10 }}
        />

        {error && <p style={{ color: "red" }}>{error}</p>}

        <button
          type="submit"
          style={{ width: "100%", padding: 10, background: "black", color: "white", borderRadius: 5 }}
        >
          {isRegister ? "Registrarse" : "Entrar"}
        </button>
      </form>

      <p style={{ marginTop: 10, textAlign: "center" }}>
        {isRegister ? "¿Ya tienes cuenta?" : "¿No tienes cuenta?"}{" "}
        <span
          style={{ color: "blue", cursor: "pointer" }}
          onClick={() => setIsRegister(!isRegister)}
        >
          {isRegister ? "Inicia sesión" : "Regístrate"}
        </span>
      </p>
    </div>
  );
}
