import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home.jsx";
import ListaConductores from "./pages/ListaDoctores.jsx";
import Login from "./pages/Login.jsx";

function App() {
  return (
    <Router>
      <Routes>
        {/* Página de inicio (pasajeros) */}
        <Route path="/" element={<Home />} />

        {/* Vista de lista de conductores */}
        <Route path="/conductores" element={<ListaConductores />} />

        {/* Login para pasajeros */}
        <Route path="/login-pasajero" element={<Login role="pasajero" />} />

        {/* Login para conductores */}
        <Route path="/login-conductor" element={<Login role="conductor" />} />

        {/* Panel conductor (falta crearla) */}
        <Route path="/panel-conductor" element={<div>Panel del Conductor (pendiente)</div>} />
      </Routes>
    </Router>
  );
}

export default App;
